package com.ildo.fastlauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable

/** Fabrique des icônes de forme uniforme, stockées en mémoire GPU (une seule copie, taille exacte). */
object IconFactory {

    private val dstIn = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
    }

    private fun path(shape: String, s: Float): Path {
        val p = Path()
        when (shape) {
            "circle" -> p.addCircle(s / 2f, s / 2f, s / 2f, Path.Direction.CW)
            "rounded" -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.26f, s * 0.26f, Path.Direction.CW)
            "square" -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.09f, s * 0.09f, Path.Direction.CW)
            else -> {
                val r = s / 2f
                val steps = 96
                for (i in 0..steps) {
                    val t = Math.PI * 2.0 * i / steps
                    val ct = Math.cos(t)
                    val st = Math.sin(t)
                    val x = r + r * Math.signum(ct) * Math.pow(Math.abs(ct), 0.5)
                    val y = r + r * Math.signum(st) * Math.pow(Math.abs(st), 0.5)
                    if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
                }
                p.close()
            }
        }
        return p
    }

    /** Masque antialiasé, créé une seule fois par chargement. Retourne null pour "original". */
    fun mask(shape: String, size: Int): Bitmap? {
        if (shape == "original") return null
        val m = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.WHITE
        Canvas(m).drawPath(path(shape, size.toFloat()), paint)
        return m
    }

    fun render(d: Drawable, size: Int, mask: Bitmap?): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (mask == null) {
            d.setBounds(0, 0, size, size)
            d.draw(c)
        } else {
            if (d is AdaptiveIconDrawable) {
                val o = (size * 0.25f).toInt()
                val bg = d.background
                val fg = d.foreground
                if (bg != null) { bg.setBounds(-o, -o, size + o, size + o); bg.draw(c) }
                if (fg != null) { fg.setBounds(-o, -o, size + o, size + o); fg.draw(c) }
            } else {
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.color = Color.rgb(241, 241, 245)
                c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
                val inset = (size * 0.16f).toInt()
                d.setBounds(inset, inset, size - inset, size - inset)
                d.draw(c)
            }
            c.drawBitmap(mask, 0f, 0f, dstIn)
        }
        return toGpu(bmp)
    }

    private fun toGpu(b: Bitmap): Bitmap {
        val h = try { b.copy(Bitmap.Config.HARDWARE, false) } catch (e: Exception) { null }
        return if (h != null) { b.recycle(); h } else b
    }
}
