package com.ildo.fastlauncher

import android.content.Context
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.LinearLayout
import kotlin.math.abs

/** Évite les tampons hors-écran (VRAM) quand on anime l'opacité du tiroir. */
class FastLinear @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : LinearLayout(c, a) {
    override fun hasOverlappingRendering(): Boolean = false
}

/**
 * Couche d'accueil : détecte le glissement vers le haut (ouvre le tiroir, suit le doigt),
 * vers le bas (notifications) et l'appui long sur une zone vide, même quand le geste
 * commence sur une icône.
 */
class HomeLayer @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : FrameLayout(c, a) {

    var onUpDragBegin: ((MotionEvent) -> Unit)? = null
    var onDrag: ((MotionEvent) -> Unit)? = null
    var onSwipeDown: (() -> Unit)? = null
    var onLongPressEmpty: (() -> Unit)? = null

    private val slop = ViewConfiguration.get(c).scaledTouchSlop
    private val dens = c.resources.displayMetrics.density
    private var downX = 0f
    private var downY = 0f
    private var mode = 0 // 0 rien, 1 haut, 2 bas
    private var gotDown = false

    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onLongPress(e: MotionEvent) {
            onLongPressEmpty?.invoke()
        }
    })

    override fun hasOverlappingRendering(): Boolean = false

    private fun detect(e: MotionEvent) {
        val dx = e.rawX - downX
        val dy = e.rawY - downY
        if (abs(dy) > slop && abs(dy) > abs(dx)) {
            if (dy < 0) {
                mode = 1
                onUpDragBegin?.invoke(e)
            } else {
                mode = 2
            }
        }
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; mode = 0 }
            MotionEvent.ACTION_MOVE -> if (mode == 0) detect(e)
        }
        return mode != 0
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            downX = e.rawX; downY = e.rawY; mode = 0; gotDown = true
        }
        if (gotDown) gd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                if (mode == 0) detect(e)
                if (mode == 1) onDrag?.invoke(e)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode == 1) {
                    onDrag?.invoke(e)
                } else if (mode == 2 && e.actionMasked == MotionEvent.ACTION_UP && e.rawY - downY > 90 * dens) {
                    onSwipeDown?.invoke()
                }
                mode = 0
                gotDown = false
            }
        }
        return true
    }
}
