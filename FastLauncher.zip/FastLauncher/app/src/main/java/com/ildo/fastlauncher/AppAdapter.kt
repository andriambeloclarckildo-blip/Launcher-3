package com.ildo.fastlauncher

import android.annotation.SuppressLint
import android.content.ComponentName
import android.graphics.Bitmap
import android.graphics.Color
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView

data class AppEntry(
    val label: String,
    val orig: String,
    val pkg: String,
    val component: ComponentName,
    val icon: Bitmap
)

/** Effet "ressort" au toucher, même courbe partout. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressEffect() {
    setOnTouchListener { v, e ->
        if (Motion.press) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(Motion.dur(110)).setInterpolator(Motion.ease).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(Motion.dur(260)).setInterpolator(OvershootInterpolator(2.2f)).start()
            }
        }
        false
    }
}

class AppAdapter(
    private val onClick: (View, AppEntry) -> Unit,
    private val onLong: (View, AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    var showLabels = true
    var labelSp = 12f
    var iconPx = 140
    var textColor = Color.WHITE
    var shadow = false
    private var styleVersion = 0

    private var items: List<AppEntry> = emptyList()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
        var styled = -1
    }

    fun refreshStyle() {
        styleVersion++
        notifyDataSetChanged()
    }

    fun submit(list: List<AppEntry>) {
        val old = items
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = list.size
            override fun areItemsTheSame(a: Int, b: Int) = old[a].component == list[b].component
            override fun areContentsTheSame(a: Int, b: Int) = old[a] == list[b]
        })
        items = list
        diff.dispatchUpdatesTo(this)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val v = LayoutInflater.from(p.context).inflate(R.layout.item_app, p, false)
        val vh = VH(v)
        v.pressEffect()
        v.setOnClickListener {
            val pos = vh.bindingAdapterPosition
            if (pos >= 0) onClick(vh.icon, items[pos])
        }
        v.setOnLongClickListener {
            val pos = vh.bindingAdapterPosition
            if (pos >= 0) onLong(vh.icon, items[pos])
            true
        }
        return vh
    }

    override fun onBindViewHolder(h: VH, i: Int) {
        val e = items[i]
        if (h.styled != styleVersion) {
            h.styled = styleVersion
            val lp = h.icon.layoutParams
            lp.width = iconPx
            lp.height = iconPx
            h.icon.layoutParams = lp
            h.label.visibility = if (showLabels) View.VISIBLE else View.GONE
            h.label.textSize = labelSp
            h.label.setTextColor(textColor)
            h.label.setShadowLayer(if (shadow) 6f else 0f, 0f, 2f, 0x66000000)
        }
        h.icon.setImageBitmap(e.icon)
        h.label.text = e.label
    }

    override fun getItemCount() = items.size
}
