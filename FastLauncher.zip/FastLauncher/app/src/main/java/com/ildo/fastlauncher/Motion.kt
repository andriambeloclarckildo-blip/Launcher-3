package com.ildo.fastlauncher

import android.view.animation.Interpolator
import android.view.animation.PathInterpolator

/** Réglages d'animation uniques : toutes les animations du launcher passent par ici (cohérence). */
object Motion {
    val ease: Interpolator = PathInterpolator(0.05f, 0.7f, 0.1f, 1f)
    var enabled = true
    var press = true
    var stiff = 380f
    var mul = 1f

    fun dur(ms: Long): Long = if (!enabled) 0L else (ms * mul).toLong()

    fun apply(mode: String) {
        when (mode) {
            "off" -> { enabled = false }
            "fast" -> { enabled = true; stiff = 700f; mul = 0.7f }
            "soft" -> { enabled = true; stiff = 220f; mul = 1.4f }
            else -> { enabled = true; stiff = 380f; mul = 1f }
        }
    }
}
