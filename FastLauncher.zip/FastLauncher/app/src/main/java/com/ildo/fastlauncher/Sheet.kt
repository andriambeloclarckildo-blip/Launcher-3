package com.ildo.fastlauncher

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

class SheetItem(val label: String, val action: () -> Unit)

/** Petit menu qui monte du bas de l'écran (même animation partout). */
fun Activity.showSheet(title: String?, items: List<SheetItem>) {
    val dp = resources.displayMetrics.density
    val d = Dialog(this, R.style.SheetDialog)
    val box = LinearLayout(this)
    box.orientation = LinearLayout.VERTICAL
    box.setBackgroundResource(R.drawable.sheet_bg)
    box.setPadding((8 * dp).toInt(), (14 * dp).toInt(), (8 * dp).toInt(), (24 * dp).toInt())

    if (title != null) {
        val t = TextView(this)
        t.text = title
        t.textSize = 13f
        t.setTextColor(Color.argb(150, 255, 255, 255))
        t.maxLines = 1
        t.setPadding((16 * dp).toInt(), (6 * dp).toInt(), (16 * dp).toInt(), (10 * dp).toInt())
        box.addView(t)
    }

    val tv = TypedValue()
    theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
    for (item in items) {
        val row = TextView(this)
        row.text = item.label
        row.textSize = 16f
        row.setTextColor(Color.WHITE)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding((16 * dp).toInt(), 0, (16 * dp).toInt(), 0)
        row.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (52 * dp).toInt())
        if (tv.resourceId != 0) row.setBackgroundResource(tv.resourceId)
        row.setOnClickListener {
            d.dismiss()
            item.action()
        }
        box.addView(row)
    }
    d.setContentView(box)
    val w = d.window
    if (w != null) {
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w.setGravity(Gravity.BOTTOM)
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        w.setDimAmount(0.45f)
    }
    d.show()
}
