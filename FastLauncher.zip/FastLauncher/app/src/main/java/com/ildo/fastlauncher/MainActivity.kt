package com.ildo.fastlauncher

import android.app.ActivityOptions
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updateLayoutParams
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var root: View
    private lateinit var home: HomeLayer
    private lateinit var drawer: View
    private lateinit var search: EditText
    private lateinit var clockBox: LinearLayout
    private lateinit var clock: TextClock
    private lateinit var date: TextClock
    private lateinit var bottomBox: View
    private lateinit var dockBox: LinearLayout
    private lateinit var appsView: RecyclerView
    private lateinit var pinView: RecyclerView
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var pinAdapter: AppAdapter

    private val io = Executors.newSingleThreadExecutor()
    private var all: List<AppEntry> = emptyList()
    private var visible: List<AppEntry> = emptyList()
    private var shown: List<AppEntry> = emptyList()
    private var loadGen = 0
    private var iconCfg = ""
    private var insetTop = 0
    private var insetBottom = 0

    private var lightMode = false
    private var parallax = true

    // état du tiroir : 0 = fermé, 1 = ouvert
    private var progress = 0f
    private var anim: SpringAnimation? = null
    private var dragging = false
    private var dragY0 = 0f
    private var dragP0 = 0f
    private var lastY = 0f
    private var lastT = 0L
    private var velY = 0f
    private val screenH: Float get() = root.height.toFloat().coerceAtLeast(1f)
    private val travel: Float get() = screenH * 0.7f

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            loadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        home = findViewById(R.id.home)
        drawer = findViewById(R.id.drawer)
        search = findViewById(R.id.search)
        clockBox = findViewById(R.id.clockBox)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        bottomBox = findViewById(R.id.bottomBox)
        dockBox = findViewById(R.id.dockBox)
        appsView = findViewById(R.id.apps)
        pinView = findViewById(R.id.pinView)
        val slop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            insetTop = b.top
            insetBottom = b.bottom
            layoutInsets()
            insets
        }

        drawerAdapter = AppAdapter(::launch) { _, e -> showAppMenu(e) }
        pinAdapter = AppAdapter(::launch) { _, e -> showAppMenu(e) }

        appsView.layoutManager = GridLayoutManager(this, 4)
        appsView.adapter = drawerAdapter
        appsView.setHasFixedSize(true)
        appsView.setItemViewCacheSize(20)
        appsView.itemAnimator = null

        pinView.layoutManager = GridLayoutManager(this, 4)
        pinView.adapter = pinAdapter
        pinView.itemAnimator = null
        pinView.isNestedScrollingEnabled = false

        // Glisser vers le bas en haut de la liste = fermer le tiroir
        appsView.addOnItemTouchListener(object : RecyclerView.SimpleOnItemTouchListener() {
            var y0 = 0f
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> y0 = e.rawY
                    MotionEvent.ACTION_MOVE ->
                        if (!dragging && !rv.canScrollVertically(-1) && e.rawY - y0 > slop) beginDrag(e)
                }
                return dragging
            }

            override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {
                if (dragging) dragEvent(e)
            }
        })

        // Poignée du tiroir
        findViewById<View>(R.id.handleZone).setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) beginDrag(e) else if (dragging) dragEvent(e)
            true
        }

        findViewById<View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
        search.setOnEditorActionListener { _, _, _ ->
            val first = shown.firstOrNull()
            if (first != null) launch(null, first)
            true
        }

        home.onUpDragBegin = { e -> beginDrag(e) }
        home.onDrag = { e -> dragEvent(e) }
        home.onSwipeDown = {
            if (prefs.str("swipe_down", "notif") == "notif") expandNotifications()
        }
        home.onLongPressEmpty = { showHomeMenu() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (progress > 0f) settle(0f, 0f)
            }
        })

        setProgress(0f)

        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addAction(Intent.ACTION_PACKAGE_CHANGED)
        f.addDataScheme("package")
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onResume() {
        super.onResume()
        applySettings()
        if (progress == 0f && !dragging && Motion.enabled && !lightMode) {
            home.scaleX = 1.04f
            home.scaleY = 1.04f
            home.alpha = 0f
            home.animate().scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(Motion.dur(260)).setInterpolator(Motion.ease).start()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && progress > 0f) settle(0f, 0f)
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        io.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- réglages

    private fun iconPx(): Int = (prefs.int("icon_size", 52) * resources.displayMetrics.density).toInt()

    private fun wallpaperWantsDarkText(): Boolean {
        if (Build.VERSION.SDK_INT >= 27) {
            val wc = try {
                WallpaperManager.getInstance(this).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
            } catch (e: Exception) {
                null
            }
            val c = wc?.primaryColor
            if (c != null) return ColorUtils.calculateLuminance(c.toArgb()) > 0.5
        }
        return false
    }

    private fun layoutInsets() {
        val dp = resources.displayMetrics.density
        clockBox.updateLayoutParams<ViewGroup.MarginLayoutParams> { topMargin = (56 * dp).toInt() + insetTop }
        bottomBox.updateLayoutParams<ViewGroup.MarginLayoutParams> { bottomMargin = (16 * dp).toInt() + insetBottom }
        drawer.setPadding(0, insetTop, 0, insetBottom)
    }

    private fun applySettings() {
        val dp = resources.displayMetrics.density
        Motion.apply(prefs.str("anim_speed", "normal"))
        Motion.press = prefs.bool("press_effect", true)
        lightMode = prefs.bool("light_mode", false)
        parallax = prefs.bool("parallax", true)
        applyRefresh()

        val dark = when (prefs.str("text_color", "auto")) {
            "dark" -> true
            "light" -> false
            else -> wallpaperWantsDarkText()
        }
        val fg = if (dark) Color.rgb(17, 17, 20) else Color.WHITE
        val fgDim = Color.argb(204, Color.red(fg), Color.green(fg), Color.blue(fg))

        val ctl = WindowCompat.getInsetsController(window, root)
        if (ctl != null) {
            ctl.isAppearanceLightStatusBars = dark
            ctl.isAppearanceLightNavigationBars = dark
        }

        // Horloge
        val fmt = if (prefs.bool("clock_24h", true)) "HH:mm" else "h:mm"
        clock.setFormat24Hour(fmt)
        clock.setFormat12Hour(fmt)
        val dateFmt = "EEEE d MMMM"
        date.setFormat24Hour(dateFmt)
        date.setFormat12Hour(dateFmt)
        date.visibility = if (prefs.bool("show_date", true)) View.VISIBLE else View.GONE
        val size = prefs.int("clock_size", 84).toFloat()
        when (prefs.str("clock_style", "thin")) {
            "normal" -> {
                clock.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                clock.textSize = size * 0.8f
                clockBox.gravity = Gravity.CENTER_HORIZONTAL
                clockBox.setPadding(0, 0, 0, 0)
            }
            "compact" -> {
                clock.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                clock.textSize = size * 0.55f
                clockBox.gravity = Gravity.START
                clockBox.setPadding((28 * dp).toInt(), 0, 0, 0)
            }
            else -> {
                clock.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
                clock.textSize = size
                clockBox.gravity = Gravity.CENTER_HORIZONTAL
                clockBox.setPadding(0, 0, 0, 0)
            }
        }
        clock.setTextColor(fg)
        date.setTextColor(fgDim)
        val shadowR = if (dark) 0f else 12f
        clock.setShadowLayer(shadowR, 0f, 2f, Color.argb(85, 0, 0, 0))
        date.setShadowLayer(shadowR, 0f, 1f, Color.argb(85, 0, 0, 0))

        home.background = if (dark) null else ContextCompat.getDrawable(this, R.drawable.home_scrim)

        // Dock
        val dockBg = GradientDrawable()
        dockBg.cornerRadius = 30 * dp
        dockBg.setColor(if (dark) Color.argb(110, 255, 255, 255) else Color.argb(50, 255, 255, 255))
        dockBg.setStroke((1 * dp).toInt().coerceAtLeast(1), Color.argb(40, 255, 255, 255))
        dockBox.background = dockBg

        // Tiroir
        drawer.setBackgroundColor(Color.argb(prefs.int("drawer_opacity", 94) * 255 / 100, 10, 10, 14))
        val px = iconPx()
        val showLabels = prefs.bool("show_labels", true)
        val labelSp = prefs.int("label_size", 12).toFloat()

        drawerAdapter.showLabels = showLabels
        drawerAdapter.labelSp = labelSp
        drawerAdapter.iconPx = px
        drawerAdapter.textColor = Color.WHITE
        drawerAdapter.shadow = false
        drawerAdapter.refreshStyle()

        pinAdapter.showLabels = showLabels
        pinAdapter.labelSp = labelSp
        pinAdapter.iconPx = px
        pinAdapter.textColor = fg
        pinAdapter.shadow = !dark
        pinAdapter.refreshStyle()

        (appsView.layoutManager as GridLayoutManager).spanCount = prefs.str("drawer_cols", "4").toIntOrNull() ?: 4
        (pinView.layoutManager as GridLayoutManager).spanCount = prefs.str("home_cols", "4").toIntOrNull() ?: 4

        setProgress(progress)

        val cfg = px.toString() + "|" + prefs.str("icon_shape", "squircle")
        if (cfg != iconCfg) {
            iconCfg = cfg
            loadApps()
        } else {
            rebuildHome()
        }
    }

    @Suppress("DEPRECATION")
    private fun applyRefresh() {
        try {
            val disp = windowManager.defaultDisplay
            val cur = disp.mode
            val same = disp.supportedModes.filter {
                it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight
            }
            val id = when (prefs.str("refresh", "max")) {
                "max" -> same.maxByOrNull { it.refreshRate }?.modeId ?: 0
                "low" -> same.minByOrNull { it.refreshRate }?.modeId ?: 0
                else -> 0
            }
            val lp = window.attributes
            if (lp.preferredDisplayModeId != id) {
                lp.preferredDisplayModeId = id
                window.attributes = lp
            }
        } catch (e: Exception) {
        }
    }

    // ---------------------------------------------------------------- tiroir (progression + ressort)

    private fun setProgress(v: Float) {
        val p = v.coerceIn(0f, 1f)
        progress = p
        drawer.visibility = if (p <= 0f) View.INVISIBLE else View.VISIBLE
        home.visibility = if (p >= 1f) View.INVISIBLE else View.VISIBLE
        drawer.translationY = (1f - p) * screenH
        if (lightMode) {
            drawer.alpha = 1f
            home.alpha = 1f
            home.scaleX = 1f
            home.scaleY = 1f
        } else {
            drawer.alpha = (p * 1.8f).coerceAtMost(1f)
            home.alpha = 1f - p
            if (parallax) {
                val s = 1f - 0.07f * p
                home.scaleX = s
                home.scaleY = s
            } else {
                home.scaleX = 1f
                home.scaleY = 1f
            }
        }
    }

    private fun beginDrag(e: MotionEvent) {
        anim?.cancel()
        home.animate().cancel()
        dragging = true
        dragY0 = e.rawY
        dragP0 = progress
        lastY = e.rawY
        lastT = e.eventTime
        velY = 0f
    }

    private fun dragEvent(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                val dt = e.eventTime - lastT
                if (dt > 0) {
                    val inst = (e.rawY - lastY) / dt * 1000f
                    velY = velY * 0.5f + inst * 0.5f
                    lastY = e.rawY
                    lastT = e.eventTime
                }
                setProgress(dragP0 + (dragY0 - e.rawY) / travel)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                if (e.eventTime - lastT > 90) velY = 0f
                val open = if (abs(velY) > 900f) velY < 0 else progress > 0.5f
                settle(if (open) 1f else 0f, -velY / travel)
            }
        }
    }

    private fun settle(target: Float, velocity: Float) {
        anim?.cancel()
        if (!Motion.enabled) {
            setProgress(target)
            afterSettle(target)
            return
        }
        val a = SpringAnimation(FloatValueHolder(progress))
        a.setSpring(SpringForce(target).setStiffness(Motion.stiff).setDampingRatio(0.92f))
        a.setStartVelocity(velocity)
        a.setMinimumVisibleChange(0.001f)
        a.addUpdateListener { _, v, _ -> setProgress(v) }
        a.addEndListener { _, canceled, _, _ ->
            if (!canceled) {
                setProgress(target)
                afterSettle(target)
            }
        }
        anim = a
        a.start()
    }

    private fun afterSettle(target: Float) {
        if (target == 0f) {
            search.setText("")
            hideKeyboard()
        }
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
    }

    // ---------------------------------------------------------------- apps

    private fun loadApps() {
        val gen = ++loadGen
        val px = iconPx()
        val shape = prefs.str("icon_shape", "squircle")
        val renames = prefs.renames()
        io.execute {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val mask = IconFactory.mask(shape, px)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    val cn = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
                    val orig = ri.loadLabel(pm).toString()
                    AppEntry(
                        renames[cn.flattenToString()] ?: orig, orig,
                        ri.activityInfo.packageName, cn,
                        IconFactory.render(ri.loadIcon(pm), px, mask)
                    )
                }
                .sortedBy { it.label.lowercase() }
            mask?.recycle()
            runOnUiThread {
                if (gen == loadGen && !isDestroyed) {
                    all = list
                    onAppsChanged()
                }
            }
        }
    }

    private fun onAppsChanged() {
        if (!prefs.sp.contains("dock") && all.isNotEmpty()) {
            val defaults = listOf(
                Intent(Intent.ACTION_DIAL),
                Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")),
                Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            )
            val cns = ArrayList<String>()
            for (i in defaults) {
                val pkg = packageManager.resolveActivity(i, 0)?.activityInfo?.packageName ?: continue
                val e = all.firstOrNull { it.pkg == pkg } ?: continue
                val k = e.component.flattenToString()
                if (k !in cns) cns.add(k)
            }
            prefs.setList("dock", cns)
        }
        val hidden = prefs.list("hidden").toSet()
        visible = all.filter { it.component.flattenToString() !in hidden }
        applyFilter()
        rebuildHome()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown = if (q.isEmpty()) {
            visible
        } else {
            visible.filter { it.label.lowercase().contains(q) }
                .sortedBy { if (it.label.lowercase().startsWith(q)) 0 else 1 }
        }
        drawerAdapter.submit(shown)
    }

    private fun rebuildHome() {
        val byComp = all.associateBy { it.component.flattenToString() }
        pinAdapter.submit(prefs.list("pins").mapNotNull { byComp[it] })

        dockBox.removeAllViews()
        val px = iconPx()
        val entries = prefs.list("dock").mapNotNull { byComp[it] }.take(5)
        for (e in entries) {
            val iv = ImageView(this)
            iv.layoutParams = LinearLayout.LayoutParams(0, px, 1f)
            iv.setImageBitmap(e.icon)
            iv.pressEffect()
            iv.setOnClickListener { launch(it, e) }
            iv.setOnLongClickListener { showAppMenu(e); true }
            dockBox.addView(iv)
        }
        dockBox.visibility = if (prefs.bool("show_dock", true) && entries.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun launch(v: View?, a: AppEntry) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(a.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val opts = if (v != null && prefs.bool("launch_zoom", true)) {
            ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height).toBundle()
        } else {
            ActivityOptions.makeCustomAnimation(this, R.anim.fade_in, R.anim.fade_out).toBundle()
        }
        try { startActivity(i, opts) } catch (e: Exception) { }
        if (progress > 0f) settle(0f, 0f)
    }

    // ---------------------------------------------------------------- menus

    private fun showAppMenu(e: AppEntry) {
        val key = e.component.flattenToString()
        val pins = prefs.list("pins")
        val dock = prefs.list("dock")
        val items = ArrayList<SheetItem>()

        if (key in pins) {
            items.add(SheetItem("Retirer de l'accueil") {
                prefs.setList("pins", pins - key)
                rebuildHome()
            })
        } else {
            items.add(SheetItem("Épingler à l'accueil") {
                if (pins.size >= 16) {
                    Toast.makeText(this, "Accueil plein (16 max)", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.setList("pins", pins + key)
                    rebuildHome()
                }
            })
        }
        if (key in dock) {
            items.add(SheetItem("Retirer du dock") {
                prefs.setList("dock", dock - key)
                rebuildHome()
            })
        } else {
            items.add(SheetItem("Ajouter au dock") {
                if (dock.size >= 5) {
                    Toast.makeText(this, "Dock plein (5 max)", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.setList("dock", dock + key)
                    rebuildHome()
                }
            })
        }
        items.add(SheetItem("Renommer") { renameApp(e) })
        items.add(SheetItem("Masquer de la liste") {
            prefs.setList("hidden", prefs.list("hidden") + key)
            onAppsChanged()
            Toast.makeText(this, "Pour la réafficher : Réglages > Apps masquées", Toast.LENGTH_LONG).show()
        })
        items.add(SheetItem("Infos de l'application") {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + e.pkg)))
            } catch (ex: Exception) { }
        })
        items.add(SheetItem("Désinstaller") {
            try {
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + e.pkg)))
            } catch (ex: Exception) { }
        })
        showSheet(e.label, items)
    }

    private fun renameApp(e: AppEntry) {
        val input = EditText(this)
        input.setText(e.label)
        input.setSelection(input.text.length)
        AlertDialog.Builder(this)
            .setTitle("Renommer")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                val t = input.text.toString().replace("\n", " ").trim()
                val key = e.component.flattenToString()
                val m = prefs.renames().toMutableMap()
                if (t.isEmpty() || t == e.orig) m.remove(key) else m[key] = t
                prefs.setRenames(m)
                val newLabel = m[key] ?: e.orig
                all = all.map { if (it.component == e.component) it.copy(label = newLabel) else it }
                    .sortedBy { it.label.lowercase() }
                onAppsChanged()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showHomeMenu() {
        val items = ArrayList<SheetItem>()
        items.add(SheetItem("Fond d'écran") {
            try {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Fond d'écran"))
            } catch (ex: Exception) { }
        })
        items.add(SheetItem("Réglages du launcher") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        items.add(SheetItem("Launcher par défaut") {
            try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch (ex: Exception) { }
        })
        showSheet("Fast Launcher", items)
    }

    private fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) {
        }
    }
}
