package com.ildo.fastlauncher

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager

class Prefs(ctx: Context) {
    val sp: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(ctx)

    fun str(k: String, d: String): String = sp.getString(k, d) ?: d
    fun int(k: String, d: Int): Int = try { sp.getInt(k, d) } catch (e: ClassCastException) { d }
    fun bool(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)

    fun list(k: String): List<String> =
        (sp.getString(k, "") ?: "").split("\n").filter { it.isNotBlank() }

    fun setList(k: String, v: List<String>) {
        sp.edit().putString(k, v.joinToString("\n")).apply()
    }

    fun renames(): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        for (l in (sp.getString("renames", "") ?: "").split("\n")) {
            val i = l.indexOf('\t')
            if (i > 0) m[l.substring(0, i)] = l.substring(i + 1)
        }
        return m
    }

    fun setRenames(m: Map<String, String>) {
        sp.edit().putString("renames", m.entries.joinToString("\n") { it.key + "\t" + it.value }).apply()
    }
}
