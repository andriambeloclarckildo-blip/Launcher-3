package com.ildo.fastlauncher

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<View>(R.id.back).setOnClickListener { finish() }
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction().replace(R.id.container, PrefsFragment()).commit()
        }
    }
}

class PrefsFragment : PreferenceFragmentCompat() {

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.prefs, rootKey)

        findPreference<Preference>("hidden_apps")?.setOnPreferenceClickListener { pickHidden(); true }
        findPreference<Preference>("default_launcher")?.setOnPreferenceClickListener {
            try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch (e: Exception) { }
            true
        }
        findPreference<Preference>("reset_home")?.setOnPreferenceClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Réinitialiser l'accueil ?")
                .setMessage("Les apps épinglées et le dock reviennent à leur état d'origine.")
                .setPositiveButton("Oui") { _, _ ->
                    Prefs(requireContext()).sp.edit().remove("pins").remove("dock").apply()
                }
                .setNegativeButton("Non", null)
                .show()
            true
        }
        findPreference<Preference>("reset_all")?.setOnPreferenceClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Tout réinitialiser ?")
                .setMessage("Tous les réglages, noms personnalisés, apps masquées, épinglées et le dock seront remis à zéro.")
                .setPositiveButton("Oui") { _, _ ->
                    Prefs(requireContext()).sp.edit().clear().apply()
                    requireActivity().recreate()
                }
                .setNegativeButton("Non", null)
                .show()
            true
        }
    }

    private fun pickHidden() {
        val ctx = requireContext()
        val pm = ctx.packageManager
        val p = Prefs(ctx)
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map {
                Pair(
                    ComponentName(it.activityInfo.packageName, it.activityInfo.name).flattenToString(),
                    it.loadLabel(pm).toString()
                )
            }
            .sortedBy { it.second.lowercase() }
        val hidden = p.list("hidden").toMutableSet()
        val checked = BooleanArray(list.size) { list[it].first in hidden }
        val names = Array(list.size) { list[it].second }
        AlertDialog.Builder(ctx)
            .setTitle("Apps masquées")
            .setMultiChoiceItems(names, checked) { _, i, on ->
                if (on) hidden.add(list[i].first) else hidden.remove(list[i].first)
            }
            .setPositiveButton("OK") { _, _ -> p.setList("hidden", hidden.toList()) }
            .setNegativeButton("Annuler", null)
            .show()
    }
}
