plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ildo.fastlauncher"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.ildo.fastlauncher"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "2.0"
    }
    // Clé de signature fixe : les mises à jour futures s'installent PAR-DESSUS l'ancienne version.
    signingConfigs {
        create("fl") {
            storeFile = file("fastlauncher.p12")
            storeType = "pkcs12"
            storePassword = "fastlauncher"
            keyAlias = "fl"
            keyPassword = "fastlauncher"
        }
    }
    buildTypes {
        // Même la variante "debug" est ici optimisée (R8, non débogable) : bien plus fluide.
        getByName("debug") {
            isDebuggable = false
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("fl")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        getByName("release") {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("fl")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.dynamicanimation:dynamicanimation:1.0.0")
    implementation("androidx.preference:preference-ktx:1.2.1")
}
